package Browser;

public class Browser {
}
